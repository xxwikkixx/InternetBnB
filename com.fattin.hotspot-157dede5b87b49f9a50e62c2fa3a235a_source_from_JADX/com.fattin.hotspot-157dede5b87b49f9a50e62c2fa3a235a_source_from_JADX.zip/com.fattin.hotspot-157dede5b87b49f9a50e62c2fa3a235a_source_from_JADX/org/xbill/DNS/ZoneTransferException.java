package org.xbill.DNS;

public class ZoneTransferException extends Exception {
    public ZoneTransferException(String s) {
        super(s);
    }
}
