package org.xbill.DNS;

import java.io.IOException;

public class TextParseException extends IOException {
    public TextParseException(String s) {
        super(s);
    }
}
