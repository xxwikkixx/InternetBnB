package com.fattin.hotspot.helpers;

public class Log {
    public static void m3v(String tag, String msg) {
    }

    public static void m2i(String tag, String msg) {
    }

    public static void m0d(String tag, String msg) {
    }

    public static void m5w(String tag, Throwable tr) {
    }

    public static void m4w(String tag, String msg, Throwable tr) {
    }

    public static void m1e(String tag, String msg, Throwable tr) {
    }
}
