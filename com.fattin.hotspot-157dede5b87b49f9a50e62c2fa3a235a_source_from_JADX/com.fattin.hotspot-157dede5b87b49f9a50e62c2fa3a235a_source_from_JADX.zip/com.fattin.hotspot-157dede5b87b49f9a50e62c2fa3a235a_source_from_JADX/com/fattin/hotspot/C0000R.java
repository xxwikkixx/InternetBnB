package com.fattin.hotspot;

/* renamed from: com.fattin.hotspot.R */
public final class C0000R {

    /* renamed from: com.fattin.hotspot.R.attr */
    public static final class attr {
    }

    /* renamed from: com.fattin.hotspot.R.bool */
    public static final class bool {
        public static final int ga_autoActivityTracking = 2131165184;
        public static final int ga_reportUncaughtExceptions = 2131165185;
    }

    /* renamed from: com.fattin.hotspot.R.drawable */
    public static final class drawable {
        public static final int background = 2130837504;
        public static final int ic_launcher = 2130837505;
        public static final int ic_stat_example = 2130837506;
    }

    /* renamed from: com.fattin.hotspot.R.id */
    public static final class id {
        public static final int TextView01 = 2131296292;
        public static final int accessListItem_Layout = 2131296256;
        public static final int accessListItem_duration_TextView = 2131296263;
        public static final int accessListItem_earnings_TextView = 2131296261;
        public static final int accessListItem_hostname_TextView = 2131296259;
        public static final int accessListItem_label_duration_TextView = 2131296262;
        public static final int accessListItem_label_earnings_TextView = 2131296260;
        public static final int accessListItem_session_status_ImageView = 2131296257;
        public static final int accessListItem_session_status_TextView = 2131296258;
        public static final int auth_WebView = 2131296303;
        public static final int checkbox = 2131296264;
        public static final int eula_TextView = 2131296266;
        public static final int eula_agree_Button = 2131296268;
        public static final int eula_agree_CheckBox = 2131296267;
        public static final int hotspot_reg_buttons_row_LinearLayout = 2131296272;
        public static final int hotspot_reg_cancel_Button = 2131296274;
        public static final int hotspot_reg_message_TextView = 2131296275;
        public static final int hotspot_reg_price_EditText = 2131296271;
        public static final int hotspot_reg_price_TextView = 2131296270;
        public static final int hotspot_reg_register_Button = 2131296273;
        public static final int login_layout = 2131296291;
        public static final int main_access_list_ListView = 2131296278;
        public static final int main_on_off_ToggleButton = 2131296276;
        public static final int main_title_TextView = 2131296277;
        public static final int menuPreference = 2131296305;
        public static final int menuWithdraw = 2131296304;
        public static final int price_edit = 2131296280;
        public static final int price_view = 2131296279;
        public static final int register_layout = 2131296269;
        public static final int scrollView1 = 2131296265;
        public static final int user_reg_buttons_row_LinearLayout = 2131296287;
        public static final int user_reg_cancel_Button = 2131296289;
        public static final int user_reg_confirm_password_EditText = 2131296286;
        public static final int user_reg_confirm_password_TextView = 2131296285;
        public static final int user_reg_message_TextView = 2131296290;
        public static final int user_reg_password_EditText = 2131296284;
        public static final int user_reg_password_TextView = 2131296283;
        public static final int user_reg_register_Button = 2131296288;
        public static final int user_reg_username_EditText = 2131296282;
        public static final int user_reg_username_TextView = 2131296281;
        public static final int user_signin_buttons_row_LinearLayout = 2131296299;
        public static final int user_signin_cancel_Button = 2131296301;
        public static final int user_signin_header2_TextView = 2131296294;
        public static final int user_signin_login_Button = 2131296300;
        public static final int user_signin_message_TextView = 2131296302;
        public static final int user_signin_password_EditText = 2131296298;
        public static final int user_signin_password_TextView = 2131296297;
        public static final int user_signin_signup_Button = 2131296293;
        public static final int user_signin_username_EditText = 2131296296;
        public static final int user_signin_username_TextView = 2131296295;
    }

    /* renamed from: com.fattin.hotspot.R.layout */
    public static final class layout {
        public static final int accesslist = 2130903040;
        public static final int accesslistitem = 2130903041;
        public static final int checkbox = 2130903042;
        public static final int eula = 2130903043;
        public static final int hotspot_reg = 2130903044;
        public static final int main = 2130903045;
        public static final int price = 2130903046;
        public static final int user_reg = 2130903047;
        public static final int user_signin = 2130903048;
        public static final int web_auth = 2130903049;
    }

    /* renamed from: com.fattin.hotspot.R.menu */
    public static final class menu {
        public static final int contextmenu = 2131230720;
    }

    /* renamed from: com.fattin.hotspot.R.raw */
    public static final class raw {
        public static final int busybox = 2131034112;
        public static final int iptables = 2131034113;
        public static final int pkcs12_key = 2131034114;
    }

    /* renamed from: com.fattin.hotspot.R.string */
    public static final class string {
        public static final int RESULT_CODE_EMAIL_ALREADY_EXIST = 2131099707;
        public static final int RESULT_CODE_HOTSPOT_ALREADY_EXIST = 2131099710;
        public static final int RESULT_CODE_HOTSPOT_NOT_AUTHENTICATED = 2131099712;
        public static final int RESULT_CODE_HOTSPOT_NOT_REGISTERED_FOR_USER = 2131099711;
        public static final int RESULT_CODE_INVALID_AUTH_TOKEN = 2131099709;
        public static final int RESULT_CODE_INVALID_CREDENTIALS = 2131099708;
        public static final int about_title = 2131099680;
        public static final int accessListItem_label_duration = 2131099670;
        public static final int accessListItem_label_earnings = 2131099669;
        public static final int accessListItem_status_image_ContentDesc = 2131099725;
        public static final int accessList_session_status_authorized = 2131099671;
        public static final int accessList_session_status_unauthorized = 2131099672;
        public static final int app_name = 2131099649;
        public static final int business_message_access_timeout = 2131099661;
        public static final int business_message_hearbeat_timeout = 2131099660;
        public static final int button_cancel = 2131099687;
        public static final int button_login = 2131099684;
        public static final int button_ok = 2131099682;
        public static final int button_register = 2131099685;
        public static final int button_signup = 2131099683;
        public static final int button_update = 2131099686;
        public static final int crash_dialog_comment_prompt = 2131099720;
        public static final int crash_dialog_ok_toast = 2131099721;
        public static final int crash_dialog_text = 2131099719;
        public static final int crash_dialog_title = 2131099718;
        public static final int crash_notif_text = 2131099717;
        public static final int crash_notif_ticker_text = 2131099715;
        public static final int crash_notif_title = 2131099716;
        public static final int crash_toast_text = 2131099714;
        public static final int dialog_dataplan_notice = 2131099655;
        public static final int dialog_dataplan_notice_checkbox = 2131099654;
        public static final int dialog_dataplan_notice_title = 2131099653;
        public static final int eula_checkbox = 2131099722;
        public static final int eula_submit_button = 2131099723;
        public static final int eula_textview_terms = 2131099724;
        public static final int ga_trackingId = 2131099648;
        public static final int intentservice_started = 2131099668;
        public static final int main_activity_title = 2131099662;
        public static final int main_activity_toggle_off = 2131099663;
        public static final int main_activity_toggle_on = 2131099664;
        public static final int menu_about = 2131099677;
        public static final int menu_access_list = 2131099675;
        public static final int menu_preference = 2131099676;
        public static final int menu_withdraw = 2131099678;
        public static final int missing_feature_access_control = 2131099651;
        public static final int missing_feature_netfilter = 2131099650;
        public static final int missing_feature_root_permission = 2131099652;
        public static final int notification_message = 2131099667;
        public static final int notification_ticker_text = 2131099665;
        public static final int notification_title = 2131099666;
        public static final int pref_beta_title = 2131099713;
        public static final int pref_confirm_password_title = 2131099695;
        public static final int pref_hotspot_options_section_title = 2131099689;
        public static final int pref_hotspot_price_message = 2131099690;
        public static final int pref_hotspot_price_summary = 2131099691;
        public static final int pref_hotspot_price_title = 2131099688;
        public static final int pref_restore_wireless_summary = 2131099703;
        public static final int pref_restore_wireless_title = 2131099702;
        public static final int pref_send_crash_report_summary_disabled = 2131099706;
        public static final int pref_send_crash_report_summary_enabled = 2131099705;
        public static final int pref_send_crash_report_title = 2131099704;
        public static final int pref_server_auth_screen_login_title = 2131099700;
        public static final int pref_server_auth_screen_logout_title = 2131099701;
        public static final int pref_server_auth_section_title = 2131099692;
        public static final int pref_server_password_message = 2131099699;
        public static final int pref_server_password_summary = 2131099697;
        public static final int pref_server_password_title = 2131099694;
        public static final int pref_server_username_message = 2131099698;
        public static final int pref_server_username_summary = 2131099696;
        public static final int pref_server_username_title = 2131099693;
        public static final int preference_title = 2131099679;
        public static final int prerequisites_message_mobile_data_connected_check_failed = 2131099658;
        public static final int prerequisites_message_mobile_data_enabled_check_failed = 2131099657;
        public static final int prerequisites_message_server_reachable_check_failed = 2131099659;
        public static final int prerequisites_message_wifi_ap_check_failed = 2131099656;
        public static final int progress_dialog_please_wait = 2131099681;
        public static final int user_signin_header1 = 2131099673;
        public static final int user_signin_header2 = 2131099674;
    }

    /* renamed from: com.fattin.hotspot.R.xml */
    public static final class xml {
        public static final int preference = 2130968576;
    }
}
