package com.fattin.hotspot;

public final class BuildConfig {
    public static final boolean DEBUG = true;
}
