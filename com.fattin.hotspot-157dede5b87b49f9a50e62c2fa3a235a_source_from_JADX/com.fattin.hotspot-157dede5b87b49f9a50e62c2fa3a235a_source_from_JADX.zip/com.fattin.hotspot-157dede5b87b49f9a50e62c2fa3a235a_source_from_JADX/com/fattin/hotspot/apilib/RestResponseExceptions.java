package com.fattin.hotspot.apilib;

public class RestResponseExceptions {

    public static class APIUserAuthTokenInvalidException extends Exception {
        private static final long serialVersionUID = -1725102974091193009L;
    }
}
